export * as en from "./en.json"
export * as sp from "./sp.json"
